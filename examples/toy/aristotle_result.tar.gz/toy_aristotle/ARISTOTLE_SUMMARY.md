# Summary of changes for run af5eda4e-df75-4d21-a6f0-031b53377952
Both `sorry`s in `Toy/Basic.lean` are now filled in, and the project builds cleanly with no remaining `sorry` and no added axioms.

- `two_mul_eq_add (n : Nat) : 2 * n = n + n` — closed by `omega`.
- `sumOdd_eq_sq (n : Nat) : sumOdd n = n * n` — closed by induction on `n`: base case `rfl`, successor case unfolds `sumOdd`, rewrites with the induction hypothesis and the multiplication-successor lemmas, then finishes with `omega`.

Following your stated preference, the proofs are short tactic proofs using `omega`/`simp` with induction where needed, and the theorem statements (and the `sumOdd` definition) are unchanged.

Also added at the project root:
- `SUMMARY.md` — short description of the work.
- `AXIOMS.txt` — `#print axioms` output for each theorem; both depend only on `propext` and `Quot.sound`.

All changes are committed and pushed.