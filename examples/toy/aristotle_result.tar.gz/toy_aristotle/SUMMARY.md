# Summary

All `sorry`s in the project have been filled in. No axioms were added.

## Changes (`Toy/Basic.lean`)

- `two_mul_eq_add (n : Nat) : 2 * n = n + n` — proved with `omega`.
- `sumOdd_eq_sq (n : Nat) : sumOdd n = n * n` — proved by induction on `n`;
  the base case is `rfl`, and the successor case unfolds `sumOdd`, rewrites with the
  induction hypothesis and the multiplication-successor lemmas, then closes with `omega`.

Theorem statements and the definition of `sumOdd` were left exactly as given.

The project builds cleanly (`lake build`) with no remaining `sorry`.
See `AXIOMS.txt` for the `#print axioms` output of each theorem.
